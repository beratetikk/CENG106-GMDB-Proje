package MovieApp;

// Interface for objects that can be rated
public interface Rateable {
    double getAverageRating();
}
